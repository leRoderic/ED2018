/* 
 * File:   main.cpp
 * Author: Rodrigo Cabezas Quirós y Sergio Barril Pizarro
 *
 * Created on 6 de marzo de 2018, 8:45
 */


/*  PREGUNTAS A RESPONDER
 * 
 * 1) Has implementado el LinkedDeque con templates? 
 * 
 * Sí, hemos implementado el LinkedDeque con templates. De este modo,
 * implementamos un código que se puede utilizar con cualquier tipo de elemento.
 * En nuestro caso en concreto, podremos hacer el Ejercicio 3 sin modificar Node
 * ni LinkedDeque
 * 
 * 
 * 2) Coste computacional operaciones de LinkedDeque
 * · isEmpty(): O(1), ya que es solo una comparación simple
 * · insertFront: O(1), ya que solo reasigna un número constante de punteros
 *     (4) y una suma.
 * · insertRear(): O(1), ya que solo reasigna un número constante de punteros
 *     (4) y una suma.   
 * · deleteFront(): O(1), ya que solo reasigna 3 punteros, hace una resta y 
 *      elimina el nodo.
 * · deleteRear(): O(1), ya que solo reasigna 3 punteros, hace una resta y 
 *      elimina el nodo.
 * · print(): O(n), ya que tiene que recorrer todos los nodos.
 * · size(): O(1), es retornar un entero.
 * · getFront(): O(1), ya que es un getter que retorna un atributo
 * · getRear(): O(1), ya que es un getter que retorna un atributo
 * 
 
 * 
 * 3) Implementar clase Node con encadenamientos simples?
 * 
 * No. Si hubiéramos implementado la clase Node con encadenamientos simples,
 * deleteRear tendría un coste de O(n), ya que para actualizar el next del penúltimo
 * nodo habría que recorrer todo el Deque.
 * 
 * Por lo tanto, con encadenamientos dobles se simplifica la implementación, y se
 * hace más eficiente.
 
 */

#include <cstdlib>
#include <iostream>
#include <vector>
#include <stdexcept>
#include "LinkedDeque.h"

using namespace std;
/*
 * 
 */

int mainMenu(vector<string> a){       
    cout << "¿Qué quieres hacer?" << endl << endl;
    for(int i = 0; i < a.size(); i++){
        cout << i + 1 <<".\t" << a[i] << endl;
    }
    int option;
    cin >> option;
    if(option > 0 && option <= a.size()){
        return option;
    }
    else{
        return -1;
    }   
}


void delFront(LinkedDeque<int> *deque){
    if(deque != nullptr){
        try{
            int elemento =  deque->getFront();
            deque->deleteFront();
            cout <<"Elemento " << elemento << " eliminado" << endl;
        }catch(out_of_range buit){
            cout << "EXCEPTION: " << buit.what() << endl;
        }
    }
}

void delRear(LinkedDeque<int> *deque){
    if(deque != nullptr){
        try{
            int elemento = deque->getRear();
            deque->deleteRear();
            cout << elemento << " eliminado del deque" << endl;
        }catch(out_of_range buit){
            cout << "EXCEPTION: " << buit.what() << endl;
        }
    }
}

void insFront(LinkedDeque<int> *deque, const int& elem){
    deque->insertFront(elem);
    cout << "Elemento " << elem << " añadido" << endl;
}

void insRear(LinkedDeque<int> *deque, const int& elem){
    deque->insertRear(elem);
    cout << "Elemento " << elem << " añadido" << endl;
}

void testCase1(){   
    LinkedDeque<int> *deque = new LinkedDeque<int>();
    cout << "Estructura creada" << endl;
    delFront(deque);
    delRear(deque);
    insFront(deque, 20);
    insFront(deque, 30);
    insRear(deque, 80);
    insRear(deque, 45);
    delFront(deque);
    deque->print();
    delete deque;
}

void testCase2(){
    LinkedDeque<int> *deque = new LinkedDeque<int>();
    cout << "Estructura creada" << endl;
    delFront(deque);
    delRear(deque);
    insFront(deque, 2);
    insFront(deque, 3);
    insRear(deque, 8);
    insRear(deque, 4);  
    delFront(deque);
    deque->print();
    delete deque;   
}

void menuDeque(vector<string> options){          
    int option, element;          
    LinkedDeque<int> *deque = new LinkedDeque<int>();
    cout << "Estructura creada" << endl;
    
    do{
        option = mainMenu(options);
        switch(option){         
            case 1:{ // insertFront();                
                cout << "Introduce el elemento:" << endl;
                cin >> element;
                insFront(deque, element);
                break;
            }
            case 2: // insertRear();                
                cout << "Introduce el elemento:" << endl;
                cin >> element;
                insRear(deque, element);
                break;
            case 3: //removeFront();
                delFront(deque);              
                break;
            case 4: //removeRear();
                delRear(deque);
                break;
            case 5:
            {
                deque->print();
                break;
            }
        }
    }while(option != 6);
    
    delete deque;
}

int main() {
    int option = 0;
       
    vector <string> modos;
    modos.push_back("Nuevo Deque");
    modos.push_back("Test Case #1");
    modos.push_back("Test Case #2");
    modos.push_back("Salir");

    vector <string> options;    
    options.push_back("Insertar al frente");
    options.push_back("Insertar al final");
    options.push_back("Eliminar por el frente");
    options.push_back("Eliminar por el final");
    options.push_back("Imprimir contenido de LinkedDeque");    
    options.push_back("Salir");
    
    cout << "*** Inicio ***" << endl << endl;        
    do{
        option = mainMenu(modos);
        switch(option){
            case 1:{ // inicializar deque                
                menuDeque(options);
                break;
            }
            case 2:{
                testCase1();
                break;
            }
            case 3:{
                testCase2();
                break;
            }
            case 4:{
                cout << "¡Hasta luego!" << endl;
                break;
            }
            default:
                cout << "Opción no válida" << endl;
        }
    }while(option != 4);                
    return 0;
}

