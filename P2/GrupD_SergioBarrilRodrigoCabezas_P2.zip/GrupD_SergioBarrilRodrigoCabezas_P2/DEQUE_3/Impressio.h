/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Impressio.h
 * Author: Sergio Barril Pizarro
 *
 * Created on 12 de abril de 2018, 11:19
 */

#include <iostream>

using namespace std;

#ifndef IMPRESSIO_H
#define IMPRESSIO_H

class Impressio {
public:
    Impressio();
    Impressio(string name, int priority, string fname);
    virtual ~Impressio();
    const int& getPriority() const;
    const string& getName() const;
    const string& getFname() const;
    
private:
    string name, fname;
    int priority;
};


#endif /* IMPRESSIO_H */

