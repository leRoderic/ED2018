/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Impressio.cpp
 * Author: Tropped
 * 
 * Created on 12 de abril de 2018, 11:19
 */

#include "Impressio.h"

Impressio::Impressio(){
    
}

Impressio::Impressio(string name, int priority, string fname) {
    this->name = name;
    this->priority = priority;
    this->fname = fname;
}

Impressio::~Impressio() {
}

const int& Impressio::getPriority() const{
    return this->priority;
}

const string& Impressio::getName() const{
    return this->name;
}

const string& Impressio::getFname() const{
    return this->fname;
}