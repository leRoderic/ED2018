/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodeTree.h
 * Author: sbarripi7.alumnes
 *
 * Created on 17 / d’abril / 2018, 08:18
 */


#ifndef NODETREE_H
#define NODETREE_H

using namespace std;

template <class Type>
class NodeTree {
    public:
        NodeTree(const Type& data);
        NodeTree(const NodeTree& orig);
        virtual ~NodeTree(); // destructor

        /*Consultors*/
        NodeTree<Type>* getright() const;
        NodeTree<Type>* getleft() const;
        NodeTree<Type>* getparent() const;
        bool hasRight() const;
        bool hasLeft() const;
        bool isRoot() const;
        bool isExternal() const;
        const Type& getElement() const;
        int getHeight() const;
        
        /*Modificadors*/
        void setHeight(int h);
        void setData(const Type& data);
        void setRight(NodeTree<Type>* newRight);
        void setLeft(NodeTree<Type>* newLeft);
        void setParent(NodeTree<Type>* newParent);
        
        private:
        NodeTree<Type>* pParent;
        NodeTree<Type>* pLeft;
        NodeTree<Type>* pRight;
        Type data;
        int height;
};

#endif /* NODETREE_H */



// Constructores y destructores 

// Constructor con parametros
template <class Type>
NodeTree<Type>::NodeTree(const Type& data):
    pParent(nullptr),
    pLeft(nullptr),
    pRight(nullptr),
    data(data),
    height(1)                
{        
}

// Constructor copia
template <class Type>
NodeTree<Type>::NodeTree(const NodeTree& orig):
    pParent(nullptr),
    pLeft(nullptr),
    pRight(nullptr),
    data(orig.data),
    height(orig.height)
{          
}

template <class Type>
NodeTree<Type>::~NodeTree(){
    
}


// Consultores

// Retorna el hijo derecho
template <class Type>
NodeTree<Type>* NodeTree<Type>::getright() const{
    return this->pRight;    
}

// Retorna el hijo izquierdo
template <class Type>
NodeTree<Type>* NodeTree<Type>::getleft() const{
    return this->pLeft;
}

// Retorna el nodo padre
template <class Type>
NodeTree<Type>* NodeTree<Type>::getparent() const{
    return this->pParent;
}

// True si tiene hijo derecho, false si no
template <class Type>
bool NodeTree<Type>::hasRight() const{    
    return !(pRight == nullptr);
}

// True si tiene hijo izquierdo, false si no
template <class Type>
bool NodeTree<Type>::hasLeft() const{
    return !(pLeft == nullptr);
}

// True si es nodo raíz, false si no
template <class Type>
bool NodeTree<Type>::isRoot() const{
    return pParent == nullptr;
}

// True si es nodo externo, false si no
template <class Type>
bool NodeTree<Type>::isExternal() const{
    return !hasRight() && !hasLeft();
}

// Retorna el elemento contenido en el nodo
template <class Type>
const Type& NodeTree<Type>::getElement() const{
    return this->data;
}

// Modificadores

// Modifica la altura del nodo
template <class Type>
void NodeTree<Type>::setHeight(int h){
    this->height = h;
}

// Modifica el elemento del nodo
template <class Type>
void NodeTree<Type>::setData(const Type& data){
    this->data = data;
}

// Cambia de nodo que tiene como hijo derecho
template <class Type>
void NodeTree<Type>::setRight(NodeTree<Type>* newRight){
    pRight = newRight;
}

// Cambia de nodo que tiene como hijo izquierdo
template <class Type>
void NodeTree<Type>::setLeft(NodeTree<Type>* newLeft){
    pLeft = newLeft;
}

// Cambia de nodo que tiene como padre
template <class Type>
void NodeTree<Type>::setParent(NodeTree<Type>* newParent){
    pParent = newParent;
}

// Retorna la altura del nodo
template <class Type>
int NodeTree<Type>::getHeight() const{
    return this->height;
}


