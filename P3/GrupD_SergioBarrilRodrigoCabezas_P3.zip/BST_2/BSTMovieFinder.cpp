/**
 * File:   BSTMovieFinder.cpp
 * Author: Tropped
 * 
 * Created on 28 de abril de 2018, 1:11
 */

#include "BSTMovieFinder.h"

// Constructor por defecto de BSTMovieFinder
BSTMovieFinder::BSTMovieFinder() {
    bst = new BinarySearchTree<Movie>();
}


// Destructor de BSTMovie Finder
BSTMovieFinder::~BSTMovieFinder() {
    delete bst;
}

// Toma como parámetro un nombre de archivo, lo lee
// y añade todas las peliculas que contiene al BST
void BSTMovieFinder::appendMovies(string filename) {
    ifstream fin;
    fin.open(filename);
    if(!fin.is_open())
        cout << "No se ha podido abrir el archivo" << endl;
    else{
        string pelicula;
        int id;
        string title;
        float rating;

        size_t idTitle;
        size_t titleRating;

        while(getline(fin, pelicula)){
            idTitle = pelicula.find("::"); // Posicion del primer delimitador
            titleRating = pelicula.rfind("::"); // Posicion del ultimo delimitador 

            // Substring + cambio de tipo        
            id = stoi(pelicula.substr(0, idTitle));
            title = pelicula.substr(idTitle + 2, titleRating - idTitle - 2);
            rating = stof(pelicula.substr(titleRating + 2, pelicula.npos));

            insertMovie(id, title, rating);  
        }

        fin.close();
    }
}

// Añade una pelicula al BST con los atributos pasados por parámetro
void BSTMovieFinder::insertMovie(int movieID, string title, float rating) {

    Movie* movie = new Movie(movieID, title, rating);
    try{    
        bst->insert(*movie, movieID);
    } catch( invalid_argument exc){
        cout << exc.what() << endl;
    }
}

// Retorna la información de la película cuyo ID se pasa por parámetro
const string BSTMovieFinder::showMovie(int movieID) const {    
    Movie pelicula = findMovie(movieID);        
    return pelicula.toString();    
}

// Retorna la pelicula cuyo ID se pasa por parámetro
const Movie& BSTMovieFinder::findMovie(int movieID) const {
    if(bst->isEmpty())
        throw out_of_range("Está vacío!");
    
    NodeTree<Movie>* node = bst->root();
    bool found = false;
    
    
    while(!found){        
        if(movieID > node->getKey()){
            if(node->hasRight())
                node = node->getright();                
            else throw invalid_argument("ID no encontrada");
        }
        
        else if(movieID < node->getKey()){
            if(node->hasLeft())
                node = node->getleft();
            else throw invalid_argument("ID no encontrada");
        }
        else found = true;                    
    }

    return node->getValue();
}

// Retorna la valoracion de la pelicula cuyo ID se pasa por parametro
const float BSTMovieFinder::findRatingMovie(int movieID) const {
    return findMovie(movieID).getRating();
}

// Iniciador de la recursion para mostrar las peliculas por orden de ID
void BSTMovieFinder::showMovies() const {
    NodeTree<Movie>* root = bst->root();
    showMovies(root);    
}

// Muestra las peliculas por orden de ID
void BSTMovieFinder::showMovies(NodeTree<Movie>* p) const {
   static int counter = 0;
    
    if(p->hasLeft()){
        showMovies(p->getleft());
    }
        
    if(counter < 40){
        cout << p->getValue().toString();
        cout << endl;
        counter++;
    }
    
    while(counter == 40){        
        cout << "Continuar? (Y/N)" << endl;
        char opt;
        cin >> opt;
        switch(toupper(opt)){
            case 'Y':
                counter = 0;
                break;
            case 'N':
                counter++;
                break;
            default:
                cout <<"Error. ";
        }
    }    
    
    if(p->hasRight()){        
        showMovies(p->getright());
    }
   
    if(p->isRoot())
       counter = 0;
}

// Dado un ID, retorna true si está en el BST, de lo contrario false
bool BSTMovieFinder::search(const int movieID) const {
    return bst->search(movieID);
}

// Retorna la profundidad del árbol
const int BSTMovieFinder::depth() const{
    return bst->root()->getHeight();
}

