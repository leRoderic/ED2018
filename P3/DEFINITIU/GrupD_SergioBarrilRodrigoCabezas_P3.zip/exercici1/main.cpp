
#include <iostream>
#include "BinarySearchTree.h"

using namespace std;


int main() {
    BinarySearchTree<int> *bst = new BinarySearchTree<int>();   //Crea nuevo BST
    
    cout << "Árbol creado" << endl;
    
    int testArray [] = {2, 0, 8, 45, 76, 5, 3, 40}; //Array para test
    for(int i = 0; i < 8; i++) {
        try{
            bst->insert(testArray[i]); //Inserta en el árbol los elementos del array
            cout << "Inserta en el árbol el elemento " << testArray[i] << endl;
        }catch(invalid_argument exc){
            cout << exc.what() << endl;
        }        
    }
    
    bst->printPreorder();   //Imprime en preorden
    cout << endl; 
    bst->printInorder();    //Imprime en inorden
    cout << endl;
    bst->printPostorder();  //Imprime en postorden
    cout << endl;
    bst->mirror();  //Crea espejo del árbol
    cout << "Árbol espejo creado" << endl;
    bst->printPreorder();  //Imprime en preorden
    delete bst; //Elimina el árbo
    cout << endl << "Árbol binario destruido" << endl;
    return 0;
}

