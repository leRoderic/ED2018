/* 
 * File:   EllipseContainer.cpp
 * Author: Sergio Barril Pizarro i Rodrigo Cabezas Quirós
 * 
 * Created on 3 de marzo de 2018, 13:55
 */

#include <stdexcept>
#include <vector>
#include "EllipseContainer.h"
#include "Circle.h"


EllipseContainer::EllipseContainer() {
}

EllipseContainer::EllipseContainer(const EllipseContainer& orig) {
}

EllipseContainer::~EllipseContainer() {
}

void EllipseContainer::addEllipse(Ellipse* ellipse) {
    if(v.size() < 10)    
        v.push_back(ellipse);
    else
        throw length_error("El vector esta ple: ja te 10 figures");
}

float EllipseContainer::getAreas(){
    vector<Ellipse *>::iterator it;
    float suma = 0;
    
    for(it = v.begin(); it != v.end(); it++)
        suma += (*it)->getArea();
    
    return suma;
}

void EllipseContainer::deleteContent(){
     vector<Ellipse *>::iterator it;
    
    for(it = v.begin(); it != v.end(); it++){
        if(dynamic_cast<Circle *>((*it))){
            cout << "Cercle eliminat" << endl;            
            delete (Circle *)((*it));
        }
        else{
            cout << "Elipse eliminada" << endl;
            delete (Ellipse *)((*it));
        }        
    }         
}